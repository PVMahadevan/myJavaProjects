
public class addOnetoTen {
	public static void main(String[] args) {

		int sum = 0;

		for (int i=1; i <= 10;i++) {
		
			sum += i;
		}
		System.out.printf("The total sum is %d\n", sum);
	}

}
