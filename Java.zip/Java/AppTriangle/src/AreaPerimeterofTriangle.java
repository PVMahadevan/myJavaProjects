class Triangle{
	int a,b,c;
	int perimeter = a + b + c;
}
public class AreaPerimeterofTriangle {
	public static void main(String[] args) {
		
		Triangle.t = new Triangle();
		
	}

}
