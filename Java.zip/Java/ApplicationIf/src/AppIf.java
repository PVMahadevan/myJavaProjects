
public class AppIf {
	public static void main(String[] args) {
		
//		int myInt = 1400;
//		
//		if(myInt >= 100) {
//			System.out.println("Yes, The number is greater");
//				}
//		else if (myInt<=100){
//			System.out.println("No, The numbers is lesser!");
		
		int loop = 0;
		
		while(loop <= 100) {
			System.out.println("Looping: " + loop);
			
			loop++;
			}
			
			if (loop <= 100);
				
				System.out.println("Running");
				
		}
		
				
	}


