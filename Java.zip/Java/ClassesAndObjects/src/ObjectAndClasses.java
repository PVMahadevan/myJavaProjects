
public class ObjectAndClasses {
	
	}
