public class JavaWhileLoop {
	public static void main(String[] args) {

		int myInt = 10;

		while (myInt <= 20) {
			System.out.println("Hello " + myInt);
			myInt = myInt + 1;
		}
		for(myInt = 10;myInt <= 30;myInt++) {
			System.out.printf("This is my age: %d\n", myInt);
		}
	}
}
