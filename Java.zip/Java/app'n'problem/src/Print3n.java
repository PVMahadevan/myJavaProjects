import java.util.Scanner;

public class Print3n {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Print the number:");
		
		int n = input.nextInt();
		
		//System.out.println("The entered number is : " + n);
		
		for (int i = 0; i <= n; i++) {
			
			i = n + (n+ 10*n);

			System.out.printf("%d", i);
			
			}
			
			//System.out.println(i);
		}
			
			//System.out.println(i);
			
			
			}

	

