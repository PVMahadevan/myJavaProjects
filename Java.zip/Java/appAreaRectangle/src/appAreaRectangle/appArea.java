package appAreaRectangle;

public class appArea {

}
