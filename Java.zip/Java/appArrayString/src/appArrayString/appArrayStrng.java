package appArrayString;

public class appArrayStrng {
	public static void main(String[] args) {

		String[] words = new String[6];

		words[0] = "I";
		words[1] = "am";
		words[2] = "Mahadevan";
		words[3] = "P";
		words[4] = "V";
		words[5] = ".";

		System.out.println(words[0] + " " + words[1] + " " + words[2] + " " + words[3] + words[4] + words[5]);

		String[] marriage = { "Mahadevan", "weds", "Aswathy" };

		for (String Marry : marriage)

		{

			System.out.println(Marry);

		}

	}
}
