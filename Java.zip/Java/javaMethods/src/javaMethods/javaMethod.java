	


package javaMethods;

public class javaMethod {

}
