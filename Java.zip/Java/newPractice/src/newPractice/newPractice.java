package newPractice;

public class newPractice {

}
